"""Structural test for SDLC-0322 — access-control management."""
import json
from pathlib import Path

MANIFEST = Path("dcs/standards/sdlc.json")

def test_sdlc_0322_schema():
    data = json.loads(MANIFEST.read_text())
    proc = next((r for r in data["requirements"] if r["id"] == "SDLC-0322"), None)
    assert proc is not None, "SDLC-0322 missing from manifest"

    for field in ['id', 'name', 'category', 'identity', 'inputs', 'outputs', 'controls', 'dependencies', 'evidence', 'metrics', 'state', 'exit_criteria', 'test']:
        assert field in proc, f"SDLC-0322 missing field: {field}"

    assert isinstance(proc["identity"], dict)
    assert isinstance(proc["inputs"], list)
    assert isinstance(proc["outputs"], list)
    assert isinstance(proc["controls"], list)
    assert isinstance(proc["dependencies"], list)
    assert isinstance(proc["evidence"], list)
    assert isinstance(proc["metrics"], list)
    assert isinstance(proc["exit_criteria"], list)

    assert proc["state"] in {'TRUE', 'CONFLICT', 'FALSE', 'UNKNOWN'}, f"SDLC-0322 invalid state: {proc['state']}"
    assert proc["test"] == "dcs.tests.sdlc.sdlc_0322"
