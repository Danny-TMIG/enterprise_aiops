"""Apoptosispoiesis — form by programmed death."""
from __future__ import annotations
import random
from dataclasses import dataclass, field
from dcs.triad.lattice import PASS, FAIL, UNKNOWN, CONFLICT, VState


@dataclass
class State:
    id: str
    payload: dict = field(default_factory=dict)
    born: int = 0
    deaths: int = 0
    status: str = "alive"


@dataclass
class Death:
    tick: int
    state_id: str
    verdict: VState
    kind: str
    evidence: dict = field(default_factory=dict)


@dataclass
class Population:
    states: list[State] = field(default_factory=list)
    log: list[Death] = field(default_factory=list)
    tick: int = 0

    def add(self, s: State):
        s.born = self.tick
        self.states.append(s)

    def alive(self):
        return [s for s in self.states if s.status == "alive"]

    def deferred(self):
        return [s for s in self.states if s.status == "deferred"]

    def conflicted(self):
        return [s for s in self.states if s.status == "conflict"]

    def step(self, sigma, *, necrotic_ratio: float = 0.0, rng=None):
        rng = rng or random.Random()
        self.tick += 1
        for s in self.alive():
            v = sigma(s)
            if v == PASS:
                s.status = "alive"
            elif v == FAIL:
                necrotic = rng.random() < necrotic_ratio
                s.status = "necrotic" if necrotic else "apoptotic"
                s.deaths += 1
                self.log.append(Death(
                    tick=self.tick, state_id=s.id, verdict=v, kind=s.status,
                    evidence={"payload_keys": sorted(s.payload.keys()),
                              "born": s.born, "lifetime": self.tick - s.born},
                ))
            elif v == UNKNOWN:
                s.status = "deferred"
            elif v == CONFLICT:
                s.status = "conflict"
        return self

    def run(self, sigma, *, max_ticks=100, necrotic_ratio=0.0, seed=0):
        rng = random.Random(seed)
        for _ in range(max_ticks):
            before = tuple(sorted(s.id for s in self.alive()))
            self.step(sigma, necrotic_ratio=necrotic_ratio, rng=rng)
            after = tuple(sorted(s.id for s in self.alive()))
            if before == after:
                break
        return self

    def form(self):
        return sorted(self.alive(), key=lambda s: (s.born, s.id))

    def stats(self):
        return {
            "tick": self.tick,
            "alive": len(self.alive()),
            "apoptotic": sum(1 for d in self.log if d.kind == "apoptotic"),
            "necrotic": sum(1 for d in self.log if d.kind == "necrotic"),
            "deferred": len(self.deferred()),
            "conflicted": len(self.conflicted()),
            "survival_rate": len(self.alive()) / max(1, len(self.states)),
        }


def sigma_from_triad(kernel, spec_for):
    def sigma(s: State) -> VState:
        t = kernel.verify(spec_for(s))
        return {"PASS": PASS, "FAIL": FAIL,
                "UNKNOWN": UNKNOWN, "CONFLICT": CONFLICT}[t.verdict()]
    return sigma
