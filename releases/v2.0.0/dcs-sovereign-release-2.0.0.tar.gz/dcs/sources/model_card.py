"""HuggingFace model card source — attestations from MODEL_CARD.md.

Reads a local model card with YAML frontmatter. Missing file -> U.
Present but empty -> F for the requirements it should satisfy.
"""
from __future__ import annotations

import os
import re
from pathlib import Path

from dcs.sources import Attestation, B, source

REQ_DOC = "AIG-DOC-002"
REQ_LIM = "AIG-TRANS-001"


def _card_path() -> Path | None:
    env = os.environ.get("DCS_MODEL_CARD")
    if env:
        p = Path(env)
        return p if p.exists() else None
    for candidate in ("./MODEL_CARD.md", "./ai-governance/MODEL_CARD.md"):
        p = Path(candidate)
        if p.exists():
            return p
    return None


def _read() -> str | None:
    p = _card_path()
    if p is None:
        return None
    try:
        return p.read_text()
    except Exception:  # pragma: no cover
        return None


@source(REQ_DOC)
def model_card_present() -> Attestation:
    body = _read()
    if body is None:
        return Attestation(REQ_DOC, B.U, "model_card", "no model card found")
    if len(body.strip()) < 200:
        return Attestation(REQ_DOC, B.F, "model_card", "card too short")
    sections = len(re.findall(r"^##?\s", body, re.MULTILINE))
    return Attestation(
        REQ_DOC, B.T if sections >= 3 else B.B, "model_card",
        f"{sections} sections, {len(body)} chars",
        {"sections": sections, "chars": len(body)},
    )


@source(REQ_LIM)
def limitations_documented() -> Attestation:
    body = _read()
    if body is None:
        return Attestation(REQ_LIM, B.U, "model_card", "no model card found")
    has_limits = bool(re.search(r"limitations?|limits|failure modes?", body, re.I))
    return Attestation(
        REQ_LIM, B.T if has_limits else B.F, "model_card",
        "limitations section present" if has_limits else "no limitations section",
    )
