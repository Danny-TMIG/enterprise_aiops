"""Eval report source — attestations from eval JSON.

Reads DCS_EVAL_JSON (lm-eval-harness or generic shape). Missing -> U.
"""
from __future__ import annotations

import json
import os
from pathlib import Path

from dcs.sources import Attestation, B, source

REQ_ACC = "AIG-ACC-001"


def _load() -> dict | None:
    p = os.environ.get("DCS_EVAL_JSON")
    if not p:
        for candidate in ("./ai-governance/evals.json", "./evals.json"):
            if Path(candidate).exists():
                p = candidate
                break
    if not p:
        return None
    try:
        return json.loads(Path(p).read_text())
    except Exception:  # pragma: no cover
        return None


@source(REQ_ACC)
def accuracy_reported() -> Attestation:
    d = _load()
    if d is None:
        return Attestation(REQ_ACC, B.U, "eval_report", "no eval JSON found")
    results = d.get("results", d.get("benchmarks", {}))
    if not results:
        return Attestation(REQ_ACC, B.F, "eval_report", "no benchmarks in report")
    n = len(results) if isinstance(results, (list, dict)) else 0
    return Attestation(
        REQ_ACC, B.T, "eval_report", f"{n} benchmark(s)",
        {"count": n, "keys": list(results)[:5] if isinstance(results, dict) else []},
    )
